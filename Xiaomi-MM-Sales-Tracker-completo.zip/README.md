# Xiaomi MM Sales Tracker

Proyecto Android completo para compilar una APK de depuración.

## Contenido
- App Android WebView con datos locales en el dispositivo.
- Dashboard naranja estilo Xiaomi.
- Gráficos de comisiones diarias y comparativa semanal.
- Icono Android adaptativo y fallback para versiones anteriores.
- Registro de ventas, objetivos, Amount e historial.

## Compilación
El proyecto usa Gradle y Android SDK. El workflow de GitHub Actions de ejemplo está en `.github/workflows/build.yml`.
